import sys
i=1
for eachArg in sys.argv:
    while i<len(sys.argv):
        arr=sys.argv[i]
        print(arr)
        i+=1

